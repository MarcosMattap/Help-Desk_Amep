const path = require("path");
const crypto = require("crypto");
const sqlite3 = require("sqlite3").verbose();

const dbPath = path.join(__dirname, "..", "helpdesk.db");
const db = new sqlite3.Database(dbPath);

function hasTicketConstraints(tableSql) {
  if (!tableSql) return false;
  return tableSql.includes("CHECK (status IN") && tableSql.includes("CHECK (priority IN");
}

function hasResolvedAtColumn(callback) {
  db.all("PRAGMA table_info(tickets)", (err, columns) => {
    if (err) {
      return callback(err);
    }

    const resolvedAtExists = Array.isArray(columns)
      && columns.some((column) => column.name === "resolved_at");

    return callback(null, resolvedAtExists);
  });
}

function hasCategoriesDefaultPriorityColumn(callback) {
  db.all("PRAGMA table_info(categories)", (err, columns) => {
    if (err) {
      return callback(err);
    }

    const exists = Array.isArray(columns)
      && columns.some((column) => column.name === "default_priority");

    return callback(null, exists);
  });
}

function migrateCategoriesDefaultPriorityIfNeeded(callback) {
  hasCategoriesDefaultPriorityColumn((columnErr, exists) => {
    if (columnErr) {
      return callback(columnErr);
    }

    if (exists) {
      return callback(null);
    }

    db.run(
      "ALTER TABLE categories ADD COLUMN default_priority TEXT NOT NULL DEFAULT 'media'",
      (alterErr) => callback(alterErr || null)
    );
  });
}

function migrateResolvedAtIfNeeded(callback) {
  hasResolvedAtColumn((columnErr, resolvedAtExists) => {
    if (columnErr) {
      return callback(columnErr);
    }

    if (resolvedAtExists) {
      return db.run(
        "UPDATE tickets SET resolved_at = updated_at WHERE resolved_at IS NULL AND status IN ('resolvido', 'fechado')",
        (backfillErr) => callback(backfillErr || null)
      );
    }

    db.serialize(() => {
      db.run("ALTER TABLE tickets ADD COLUMN resolved_at TEXT", (alterErr) => {
        if (alterErr) {
          return callback(alterErr);
        }

        db.run(
          "UPDATE tickets SET resolved_at = updated_at WHERE status IN ('resolvido', 'fechado')",
          (backfillErr) => callback(backfillErr || null)
        );
      });
    });
  });
}

function migrateTicketsTableIfNeeded(callback) {
  db.get("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'tickets'", (err, row) => {
    if (err) {
      return callback(err);
    }

    if (hasTicketConstraints(row && row.sql)) {
      return callback(null);
    }

    const migrationSql = `
      PRAGMA foreign_keys = OFF;
      BEGIN TRANSACTION;

      CREATE TABLE IF NOT EXISTS tickets_new (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'aberto' CHECK (status IN ('aberto', 'em_andamento', 'aguardando_usuario', 'resolvido', 'fechado')),
        priority TEXT NOT NULL DEFAULT 'media' CHECK (priority IN ('baixa', 'media', 'alta', 'critica')),
        requester_id INTEGER NOT NULL,
        assignee_id INTEGER,
        department_id INTEGER,
        category_id INTEGER,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        resolved_at TEXT,
        FOREIGN KEY (requester_id) REFERENCES users(id),
        FOREIGN KEY (assignee_id) REFERENCES users(id),
        FOREIGN KEY (department_id) REFERENCES departments(id),
        FOREIGN KEY (category_id) REFERENCES categories(id)
      );

      INSERT INTO tickets_new (
        id,
        title,
        description,
        status,
        priority,
        requester_id,
        assignee_id,
        department_id,
        category_id,
        created_at,
        updated_at,
        resolved_at
      )
      SELECT
        id,
        title,
        description,
        CASE
          WHEN status IN ('aberto', 'em_andamento', 'aguardando_usuario', 'resolvido', 'fechado') THEN status
          ELSE 'aberto'
        END,
        CASE
          WHEN priority IN ('baixa', 'media', 'alta', 'critica') THEN priority
          ELSE 'media'
        END,
        requester_id,
        assignee_id,
        department_id,
        category_id,
        created_at,
        updated_at,
        CASE
          WHEN status IN ('resolvido', 'fechado') THEN updated_at
          ELSE NULL
        END
      FROM tickets;

      DROP TABLE tickets;
      ALTER TABLE tickets_new RENAME TO tickets;

      COMMIT;
      PRAGMA foreign_keys = ON;
    `;

    db.exec(migrationSql, (migrationErr) => {
      if (migrationErr) {
        return callback(migrationErr);
      }
      console.log("Migracao aplicada: constraints de status/prioridade em tickets.");
      return callback(null);
    });
  });
}

function seedInitialAdmin() {
  // usuario admin inicial
  db.get(`SELECT COUNT(*) AS count FROM users`, (err, row) => {
    if (err) {
      console.error("Erro ao verificar usuarios iniciais:", err);
      return;
    }
    if (row.count === 0) {
      const bcrypt = require("bcryptjs");

      const adminEmail = process.env.ADMIN_EMAIL || "admin@empresa.com";
      const adminPasswordFromEnv = process.env.ADMIN_PASSWORD || "";
      const generatedAdminPassword = crypto.randomBytes(24).toString("base64url");
      const adminPassword = adminPasswordFromEnv || generatedAdminPassword;
      const isGeneratedPassword = !adminPasswordFromEnv;

      if (adminPassword.length < 12) {
        console.error(
          "ADMIN_PASSWORD invalida: use ao menos 12 caracteres para criar o admin inicial."
        );
        return;
      }

      const passwordHash = bcrypt.hashSync(adminPassword, 10);
      db.run(
        `INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)`,
        ["Administrador", adminEmail, passwordHash, "admin"],
        (err2) => {
          if (err2) {
            console.error("Erro ao criar usuario admin padrao:", err2);
          } else if (isGeneratedPassword) {
            console.log("Admin inicial criado com senha aleatoria forte.");
            console.log(`E-mail: ${adminEmail}`);
            console.log(`Senha temporaria: ${generatedAdminPassword}`);
            console.log("Altere essa senha imediatamente em Minha conta.");
          } else {
            console.log(`Admin inicial criado com ADMIN_EMAIL=${adminEmail}.`);
          }
        }
      );
    }
  });
}

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('user', 'agent', 'admin'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS departments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      default_priority TEXT NOT NULL DEFAULT 'media'
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'aberto' CHECK (status IN ('aberto', 'em_andamento', 'aguardando_usuario', 'resolvido', 'fechado')),
      priority TEXT NOT NULL DEFAULT 'media' CHECK (priority IN ('baixa', 'media', 'alta', 'critica')),
      requester_id INTEGER NOT NULL,
      assignee_id INTEGER,
      department_id INTEGER,
      category_id INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_at TEXT,
      FOREIGN KEY (requester_id) REFERENCES users(id),
      FOREIGN KEY (assignee_id) REFERENCES users(id),
      FOREIGN KEY (department_id) REFERENCES departments(id),
      FOREIGN KEY (category_id) REFERENCES categories(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS ticket_comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      comment TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (ticket_id) REFERENCES tickets(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS admin_audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_user_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id INTEGER,
      details TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (admin_user_id) REFERENCES users(id)
    )
  `);

  migrateTicketsTableIfNeeded((migrationErr) => {
    if (migrationErr) {
      console.error("Erro ao aplicar migracao da tabela tickets:", migrationErr);
      return;
    }

    migrateResolvedAtIfNeeded((resolvedAtErr) => {
      if (resolvedAtErr) {
        console.error("Erro ao aplicar migracao da coluna resolved_at:", resolvedAtErr);
        return;
      }

      migrateCategoriesDefaultPriorityIfNeeded((categoriesErr) => {
        if (categoriesErr) {
          console.error(
            "Erro ao aplicar migracao da coluna default_priority em categories:",
            categoriesErr
          );
          return;
        }

        seedInitialAdmin();
      });
    });
  });
});

module.exports = db;

