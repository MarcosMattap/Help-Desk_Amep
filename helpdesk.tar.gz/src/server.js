const path = require("path");
const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const bcrypt = require("bcryptjs");
const csrf = require("csurf");
const db = require("./db");
const { ensureAuthenticated, requireRole } = require("./middlewares/auth");
const {
  isValidTicketStatus,
  isValidTicketPriority,
} = require("./constants/tickets");

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === "production";
const sessionSecret =
  process.env.SESSION_SECRET ||
  (isProduction ? null : "dev-insecure-session-secret-change-me");

if (!sessionSecret) {
  throw new Error("SESSION_SECRET nao definido. Configure a variavel de ambiente em producao.");
}

if (isProduction) {
  // Necessario para cookies secure quando app fica atras de proxy.
  app.set("trust proxy", 1);
}

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "..", "views"));

app.use(express.static(path.join(__dirname, "..", "public")));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(
  session({
    name: "helpdesk.sid",
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: isProduction,
      maxAge: 1000 * 60 * 60 * 8,
    },
  })
);

const csrfProtection = csrf();
app.use(csrfProtection);

// deixa currentUser sempre disponível nas views
app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  res.locals.csrfToken = req.csrfToken();
  next();
});

function writeAdminAuditLog(req, action, entityType, entityId, details) {
  const adminUserId = req?.session?.user?.id;
  if (!adminUserId) return;

  db.run(
    "INSERT INTO admin_audit_logs (admin_user_id, action, entity_type, entity_id, details) VALUES (?, ?, ?, ?, ?)",
    [adminUserId, action, entityType, entityId || null, details || null],
    (err) => {
      if (err) {
        console.error("Erro ao gravar log de auditoria admin:", err);
      }
    }
  );
}

app.get("/", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }
  res.redirect("/tickets");
});

app.get("/login", (req, res) => {
  if (req.session.user) {
    return res.redirect("/tickets");
  }
  res.render("login", { error: null });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  db.get(`SELECT * FROM users WHERE email = ?`, [email], (err, user) => {
    if (err) {
      console.error(err);
      return res.render("login", { error: "Erro ao autenticar. Tente novamente." });
    }
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.render("login", { error: "E-mail ou senha inválidos." });
    }
    req.session.user = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    };
    res.redirect("/tickets");
  });
});

app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

app.get("/tickets", ensureAuthenticated, (req, res) => {
  const user = req.session.user;
  let query =
    "SELECT t.*, u.name AS requester_name, a.name AS assignee_name FROM tickets t " +
    "JOIN users u ON t.requester_id = u.id " +
    "LEFT JOIN users a ON t.assignee_id = a.id ";
  const params = [];

  if (user.role === "user") {
    query += "WHERE t.requester_id = ? ";
    params.push(user.id);
  }

  query += "ORDER BY t.created_at DESC";

  db.all(query, params, (err, tickets) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Erro ao carregar chamados.");
    }
    res.render("tickets-list", { tickets, user });
  });
});

app.get("/tickets/new", ensureAuthenticated, (req, res) => {
  db.all(`SELECT * FROM departments ORDER BY name`, [], (err, departments) => {
    if (err) return res.status(500).send("Erro ao carregar setores.");
    db.all(`SELECT * FROM categories ORDER BY name`, [], (err2, categories) => {
      if (err2) return res.status(500).send("Erro ao carregar categorias.");
      res.render("ticket-new", { departments, categories });
    });
  });
});

app.post("/tickets", ensureAuthenticated, (req, res) => {
  const { title, description, department_id, category_id, priority } = req.body;
  const requesterId = req.session.user.id;
  const normalizedPriority = isValidTicketPriority(priority) ? priority : "media";
  const safeCategoryId = category_id && Number.isInteger(Number(category_id)) ? Number(category_id) : null;

  if (!title || !description) {
    return res.status(400).send("Titulo e descricao sao obrigatorios.");
  }

  const insertTicket = (priorityToUse) => {
    const sql = `
      INSERT INTO tickets (title, description, requester_id, department_id, category_id, priority)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    db.run(
      sql,
      [
        title,
        description,
        requesterId,
        department_id || null,
        safeCategoryId,
        priorityToUse,
      ],
      (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send("Erro ao abrir chamado.");
        }
        res.redirect("/tickets");
      }
    );
  };

  if (!safeCategoryId) {
    return insertTicket(normalizedPriority);
  }

  db.get(
    "SELECT default_priority FROM categories WHERE id = ?",
    [safeCategoryId],
    (categoryErr, categoryRow) => {
      if (categoryErr) {
        console.error(categoryErr);
        return res.status(500).send("Erro ao validar categoria.");
      }

      const categoryPriority = categoryRow && isValidTicketPriority(categoryRow.default_priority)
        ? categoryRow.default_priority
        : normalizedPriority;

      return insertTicket(categoryPriority);
    }
  );
});

app.post("/admin/categories", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const name = (req.body.name || "").trim();
  const safeDefaultPriority = isValidTicketPriority(req.body.default_priority)
    ? req.body.default_priority
    : "media";
  if (!name) return res.status(400).send("Nome da categoria e obrigatorio.");
  db.run(
    "INSERT INTO categories (name, default_priority) VALUES (?, ?)",
    [name, safeDefaultPriority],
    function onCreateCategory(err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Erro ao criar categoria.");
      }
      writeAdminAuditLog(
        req,
        "CREATE",
        "category",
        this.lastID,
        `Categoria '${name}' criada com prioridade padrao '${safeDefaultPriority}'.`
      );
      res.redirect("/admin");
    }
  );
});

app.get("/tickets/:id", ensureAuthenticated, (req, res) => {
  const ticketId = req.params.id;
  const currentUser = req.session.user;
  const ticketSql =
    "SELECT t.*, u.name AS requester_name, a.name AS assignee_name, d.name AS department_name, c.name AS category_name " +
    "FROM tickets t " +
    "JOIN users u ON t.requester_id = u.id " +
    "LEFT JOIN users a ON t.assignee_id = a.id " +
    "LEFT JOIN departments d ON t.department_id = d.id " +
    "LEFT JOIN categories c ON t.category_id = c.id " +
    "WHERE t.id = ?";

  db.get(ticketSql, [ticketId], (err, ticket) => {
    if (err || !ticket) {
      console.error(err);
      return res.status(404).send("Chamado não encontrado.");
    }

    // Evita IDOR: usuario comum so pode visualizar os proprios chamados.
    if (currentUser.role === "user" && ticket.requester_id !== currentUser.id) {
      return res.status(403).send("Acesso negado.");
    }

    db.all(
      "SELECT c.*, u.name AS user_name FROM ticket_comments c JOIN users u ON c.user_id = u.id WHERE c.ticket_id = ? ORDER BY c.created_at ASC",
      [ticketId],
      (err2, comments) => {
        if (err2) {
          console.error(err2);
          return res.status(500).send("Erro ao carregar comentários.");
        }
        res.render("ticket-detail", { ticket, comments, user: req.session.user });
      }
    );
  });
});

app.post("/tickets/:id/comment", ensureAuthenticated, (req, res) => {
  const ticketId = req.params.id;
  const { comment } = req.body;
  const currentUser = req.session.user;
  const userId = currentUser.id;

  db.get("SELECT requester_id FROM tickets WHERE id = ?", [ticketId], (ticketErr, ticket) => {
    if (ticketErr) {
      console.error(ticketErr);
      return res.status(500).send("Erro ao validar chamado.");
    }

    if (!ticket) {
      return res.status(404).send("Chamado não encontrado.");
    }

    // Evita IDOR: usuario comum so pode comentar nos proprios chamados.
    if (currentUser.role === "user" && ticket.requester_id !== currentUser.id) {
      return res.status(403).send("Acesso negado.");
    }

    db.run(
      "INSERT INTO ticket_comments (ticket_id, user_id, comment) VALUES (?, ?, ?)",
      [ticketId, userId, comment],
      (err) => {
        if (err) {
          console.error(err);
          return res.status(500).send("Erro ao adicionar comentário.");
        }
        db.run(
          "UPDATE tickets SET updated_at = datetime('now') WHERE id = ?",
          [ticketId],
          () => res.redirect(`/tickets/${ticketId}`)
        );
      }
    );
  });
});

app.post("/tickets/:id/status", ensureAuthenticated, requireRole(["agent", "admin"]), (req, res) => {
  const ticketId = req.params.id;
  const { status } = req.body;
  const assigneeId = req.session.user.id;
  const isResolvedStatus = status === "resolvido" || status === "fechado";

  if (!isValidTicketStatus(status)) {
    return res.status(400).send("Status invalido.");
  }

  db.run(
    "UPDATE tickets SET status = ?, assignee_id = ?, updated_at = datetime('now'), resolved_at = CASE WHEN ? THEN COALESCE(resolved_at, datetime('now')) ELSE NULL END WHERE id = ?",
    [status, assigneeId, isResolvedStatus ? 1 : 0, ticketId],
    (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send("Erro ao atualizar status.");
      }
      res.redirect(`/tickets/${ticketId}`);
    }
  );
});

app.get("/admin", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  db.all("SELECT id, name, email, role FROM users ORDER BY name", [], (userErr, users) => {
    if (userErr) return res.status(500).send("Erro ao carregar usuários.");
    db.all("SELECT * FROM departments ORDER BY name", [], (err, departments) => {
      if (err) return res.status(500).send("Erro ao carregar setores.");
      db.all("SELECT * FROM categories ORDER BY name", [], (err2, categories) => {
        if (err2) return res.status(500).send("Erro ao carregar categorias.");
        const ticketsSql =
          "SELECT t.*, u.name AS requester_name, a.name AS assignee_name, " +
          "d.name AS department_name, c.name AS category_name " +
          "FROM tickets t " +
          "JOIN users u ON t.requester_id = u.id " +
          "LEFT JOIN users a ON t.assignee_id = a.id " +
          "LEFT JOIN departments d ON t.department_id = d.id " +
          "LEFT JOIN categories c ON t.category_id = c.id " +
          "ORDER BY CASE t.status " +
          "  WHEN 'aberto' THEN 1 WHEN 'em_andamento' THEN 2 " +
          "  WHEN 'aguardando_usuario' THEN 3 WHEN 'resolvido' THEN 4 ELSE 5 END, " +
          "t.updated_at DESC";
        db.all(ticketsSql, [], (err3, tickets) => {
          if (err3) return res.status(500).send("Erro ao carregar chamados.");
          const agents = users.filter((u) => u.role === "agent" || u.role === "admin");
          db.all(
            "SELECT l.*, u.name AS admin_name FROM admin_audit_logs l JOIN users u ON u.id = l.admin_user_id ORDER BY l.created_at DESC, l.id DESC LIMIT 50",
            [],
            (logErr, adminLogs) => {
              if (logErr) return res.status(500).send("Erro ao carregar log de auditoria.");
              res.render("admin", {
                departments,
                categories,
                users,
                tickets,
                agents,
                adminLogs,
              });
            }
          );
        });
      });
    });
  });
});

app.post("/admin/tickets/:id/assign", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const ticketId = Number.isInteger(Number(req.params.id)) ? Number(req.params.id) : null;
  if (!ticketId) return res.status(400).send("ID inválido.");
  const { assignee_id, status } = req.body;
  const safeAssigneeId = assignee_id && assignee_id !== "" ? Number(assignee_id) : null;
  const allowedStatuses = ["aberto", "em_andamento", "aguardando_usuario", "resolvido", "fechado"];
  const safeStatus = allowedStatuses.includes(status) ? status : null;
  const isResolvedStatus = safeStatus === "resolvido" || safeStatus === "fechado";
  if (!safeStatus) return res.status(400).send("Status inválido.");
  db.run(
    "UPDATE tickets SET assignee_id = ?, status = ?, updated_at = datetime('now'), resolved_at = CASE WHEN ? THEN COALESCE(resolved_at, datetime('now')) ELSE NULL END WHERE id = ?",
    [safeAssigneeId, safeStatus, isResolvedStatus ? 1 : 0, ticketId],
    (err) => {
      if (err) return res.status(500).send("Erro ao atualizar chamado.");
      writeAdminAuditLog(
        req,
        "UPDATE",
        "ticket",
        ticketId,
        `Chamado #${ticketId} atualizado: status='${safeStatus}', assignee_id='${safeAssigneeId || "null"}'.`
      );
      res.redirect("/admin");
    }
  );
});

app.post("/admin/departments", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const name = (req.body.name || "").trim();
  if (!name) return res.status(400).send("Nome do setor e obrigatorio.");
  db.run("INSERT INTO departments (name) VALUES (?)", [name], function onCreateDepartment(err) {
    if (err) console.error(err);
    if (!err) {
      writeAdminAuditLog(req, "CREATE", "department", this.lastID, `Setor '${name}' criado.`);
    }
    res.redirect("/admin");
  });
});

app.post("/admin/departments/:id/update", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const departmentId = Number(req.params.id);
  const name = (req.body.name || "").trim();
  if (!Number.isInteger(departmentId) || departmentId <= 0) {
    return res.status(400).send("ID de setor invalido.");
  }
  if (!name) return res.status(400).send("Nome do setor e obrigatorio.");

  db.run("UPDATE departments SET name = ? WHERE id = ?", [name, departmentId], (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Erro ao atualizar setor.");
    }
    writeAdminAuditLog(req, "UPDATE", "department", departmentId, `Setor #${departmentId} atualizado para '${name}'.`);
    res.redirect("/admin");
  });
});

app.post("/admin/departments/:id/delete", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const departmentId = Number(req.params.id);
  if (!Number.isInteger(departmentId) || departmentId <= 0) {
    return res.status(400).send("ID de setor invalido.");
  }

  db.get(
    "SELECT COUNT(*) as total FROM tickets WHERE department_id = ?",
    [departmentId],
    (countErr, row) => {
      if (countErr) {
        console.error(countErr);
        return res.status(500).send("Erro ao validar setor.");
      }
      if (row && row.total > 0) {
        return res
          .status(400)
          .send("Nao e possivel excluir setor vinculado a chamados.");
      }

      db.run("DELETE FROM departments WHERE id = ?", [departmentId], (deleteErr) => {
        if (deleteErr) {
          console.error(deleteErr);
          return res.status(500).send("Erro ao excluir setor.");
        }
        writeAdminAuditLog(req, "DELETE", "department", departmentId, `Setor #${departmentId} excluido.`);
        res.redirect("/admin");
      });
    }
  );
});

app.post("/admin/categories/:id/update", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const categoryId = Number(req.params.id);
  const name = (req.body.name || "").trim();
  const safeDefaultPriority = isValidTicketPriority(req.body.default_priority)
    ? req.body.default_priority
    : "media";
  if (!Number.isInteger(categoryId) || categoryId <= 0) {
    return res.status(400).send("ID de categoria invalido.");
  }
  if (!name) return res.status(400).send("Nome da categoria e obrigatorio.");

  db.run(
    "UPDATE categories SET name = ?, default_priority = ? WHERE id = ?",
    [name, safeDefaultPriority, categoryId],
    (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Erro ao atualizar categoria.");
    }
    writeAdminAuditLog(
      req,
      "UPDATE",
      "category",
      categoryId,
      `Categoria #${categoryId} atualizada para '${name}' com prioridade padrao '${safeDefaultPriority}'.`
    );
    res.redirect("/admin");
    }
  );
});

app.post("/admin/categories/:id/delete", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const categoryId = Number(req.params.id);
  if (!Number.isInteger(categoryId) || categoryId <= 0) {
    return res.status(400).send("ID de categoria invalido.");
  }

  // Remove o vínculo da categoria nos chamados para permitir exclusão segura.
  db.run("UPDATE tickets SET category_id = NULL WHERE category_id = ?", [categoryId], (updateErr) => {
    if (updateErr) {
      console.error(updateErr);
      return res.status(500).send("Erro ao desvincular categoria dos chamados.");
    }

    db.run("DELETE FROM categories WHERE id = ?", [categoryId], (deleteErr) => {
      if (deleteErr) {
        console.error(deleteErr);
        return res.status(500).send("Erro ao excluir categoria.");
      }
      writeAdminAuditLog(req, "DELETE", "category", categoryId, `Categoria #${categoryId} excluida.`);
      res.redirect("/admin");
    });
  });
});

app.post("/admin/users", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password) {
    return res.status(400).send("Nome, e-mail e senha são obrigatórios.");
  }

  const validRoles = ["user", "agent", "admin"];
  const userRole = validRoles.includes(role) ? role : "user";

  const passwordHash = bcrypt.hashSync(password, 10);

  db.run(
    "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
    [name, email, passwordHash, userRole],
    function onCreateUser(err) {
      if (err) {
        console.error(err);
        return res.status(500).send("Erro ao criar usuário (verifique se o e-mail já não existe).");
      }
      writeAdminAuditLog(req, "CREATE", "user", this.lastID, `Usuario '${name}' (${email}) criado com papel '${userRole}'.`);
      res.redirect("/admin");
    }
  );
});

app.post("/admin/users/:id/update", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const userId = Number(req.params.id);
  const name = (req.body.name || "").trim();
  const email = (req.body.email || "").trim();
  const password = (req.body.password || "").trim();
  const validRoles = ["user", "agent", "admin"];
  const role = validRoles.includes(req.body.role) ? req.body.role : "user";

  if (!Number.isInteger(userId) || userId <= 0) {
    return res.status(400).send("ID de usuario invalido.");
  }
  if (!name || !email) {
    return res.status(400).send("Nome e e-mail sao obrigatorios.");
  }

  db.get("SELECT id FROM users WHERE id = ?", [userId], (findErr, existingUser) => {
    if (findErr) {
      console.error(findErr);
      return res.status(500).send("Erro ao validar usuario.");
    }
    if (!existingUser) {
      return res.status(404).send("Usuario nao encontrado.");
    }

    if (!password) {
      db.run(
        "UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?",
        [name, email, role, userId],
        (updateErr) => {
          if (updateErr) {
            console.error(updateErr);
            return res.status(500).send("Erro ao atualizar usuario.");
          }
          writeAdminAuditLog(req, "UPDATE", "user", userId, `Usuario #${userId} atualizado para '${name}' (${email}) com papel '${role}'.`);
          res.redirect("/admin");
        }
      );
      return;
    }

    const passwordHash = bcrypt.hashSync(password, 10);
    db.run(
      "UPDATE users SET name = ?, email = ?, role = ?, password_hash = ? WHERE id = ?",
      [name, email, role, passwordHash, userId],
      (updateErr) => {
        if (updateErr) {
          console.error(updateErr);
          return res.status(500).send("Erro ao atualizar usuario.");
        }
        writeAdminAuditLog(req, "UPDATE", "user", userId, `Usuario #${userId} atualizado (incluindo senha), papel '${role}'.`);
        res.redirect("/admin");
      }
    );
  });
});

app.post("/admin/users/:id/delete", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  const userId = Number(req.params.id);
  const currentUserId = req.session.user.id;
  if (!Number.isInteger(userId) || userId <= 0) {
    return res.status(400).send("ID de usuario invalido.");
  }
  if (userId === currentUserId) {
    return res.status(400).send("Nao e permitido excluir o proprio usuario logado.");
  }

  db.get("SELECT role FROM users WHERE id = ?", [userId], (userErr, userRow) => {
    if (userErr) {
      console.error(userErr);
      return res.status(500).send("Erro ao validar usuario.");
    }
    if (!userRow) {
      return res.status(404).send("Usuario nao encontrado.");
    }

    const checkAndDelete = () => {
      db.get(
        "SELECT COUNT(*) as total FROM tickets WHERE requester_id = ? OR assignee_id = ?",
        [userId, userId],
        (ticketsErr, ticketRow) => {
          if (ticketsErr) {
            console.error(ticketsErr);
            return res.status(500).send("Erro ao validar usuario.");
          }
          if (ticketRow && ticketRow.total > 0) {
            return res
              .status(400)
              .send("Nao e possivel excluir usuario vinculado a chamados.");
          }

          db.get("SELECT COUNT(*) as total FROM ticket_comments WHERE user_id = ?", [userId], (commentErr, commentRow) => {
            if (commentErr) {
              console.error(commentErr);
              return res.status(500).send("Erro ao validar usuario.");
            }
            if (commentRow && commentRow.total > 0) {
              return res
                .status(400)
                .send("Nao e possivel excluir usuario com historico de comentarios.");
            }

            db.run("DELETE FROM users WHERE id = ?", [userId], (deleteErr) => {
              if (deleteErr) {
                console.error(deleteErr);
                return res.status(500).send("Erro ao excluir usuario.");
              }
              writeAdminAuditLog(req, "DELETE", "user", userId, `Usuario #${userId} excluido.`);
              res.redirect("/admin");
            });
          });
        }
      );
    };

    if (userRow.role !== "admin") {
      return checkAndDelete();
    }

    db.get("SELECT COUNT(*) as total FROM users WHERE role = 'admin'", [], (adminErr, adminRow) => {
      if (adminErr) {
        console.error(adminErr);
        return res.status(500).send("Erro ao validar usuario admin.");
      }
      if (adminRow && adminRow.total <= 1) {
        return res.status(400).send("Nao e permitido excluir o ultimo admin do sistema.");
      }
      return checkAndDelete();
    });
  });
});

app.get("/admin/relatorios", ensureAuthenticated, requireRole(["admin"]), (req, res) => {
  // Chamados por status
  const sqlStatus = "SELECT status, COUNT(*) as total FROM tickets GROUP BY status";
  // Chamados por prioridade
  const sqlPriority = "SELECT priority, COUNT(*) as total FROM tickets GROUP BY priority";
  // Dia da semana com mais chamados abertos
  const sqlTopWeekday =
    "SELECT strftime('%w', created_at) as weekday, COUNT(*) as total " +
    "FROM tickets GROUP BY weekday ORDER BY total DESC, weekday ASC LIMIT 1";
  // Chamados por dia da semana
  const sqlWeekdayData =
    "SELECT strftime('%w', created_at) as weekday, COUNT(*) as total " +
    "FROM tickets GROUP BY weekday ORDER BY weekday ASC";
  // Chamados por mês (últimos 6 meses)
  const sqlMonthly =
    "SELECT strftime('%Y-%m', created_at) as mes, COUNT(*) as total " +
    "FROM tickets " +
    "WHERE created_at >= date('now', '-6 months') " +
    "GROUP BY mes ORDER BY mes ASC";
  // Tempo médio de resolução em horas (chamados resolvidos ou fechados)
  const sqlAvgTime =
    "SELECT ROUND(AVG((julianday(resolved_at) - julianday(created_at)) * 24), 1) AS media_horas " +
    "FROM tickets WHERE resolved_at IS NOT NULL";
  // Top 5 categorias com mais chamados
  const sqlCategories =
    "SELECT c.name, COUNT(t.id) as total FROM tickets t " +
    "LEFT JOIN categories c ON t.category_id = c.id " +
    "GROUP BY t.category_id ORDER BY total DESC LIMIT 5";
  // Chamados por agente responsável
  const sqlAgents =
    "SELECT u.name, COUNT(t.id) as total FROM tickets t " +
    "JOIN users u ON t.assignee_id = u.id " +
    "GROUP BY t.assignee_id ORDER BY total DESC LIMIT 8";

  db.all(sqlStatus, [], (e1, statusData) => {
    if (e1) return res.status(500).send("Erro ao carregar dados.");
    db.all(sqlPriority, [], (e2, priorityData) => {
      if (e2) return res.status(500).send("Erro ao carregar dados.");
      db.get(sqlTopWeekday, [], (e3, topWeekday) => {
        if (e3) return res.status(500).send("Erro ao carregar dados.");
        db.all(sqlWeekdayData, [], (e4, weekdayData) => {
          if (e4) return res.status(500).send("Erro ao carregar dados.");
          db.all(sqlMonthly, [], (e5, monthlyData) => {
            if (e5) return res.status(500).send("Erro ao carregar dados.");
            db.get(sqlAvgTime, [], (e6, avgTime) => {
              if (e6) return res.status(500).send("Erro ao carregar dados.");
              db.all(sqlCategories, [], (e7, categoriesData) => {
                if (e7) return res.status(500).send("Erro ao carregar dados.");
                db.all(sqlAgents, [], (e8, agentsData) => {
                  if (e8) return res.status(500).send("Erro ao carregar dados.");
                  db.get("SELECT COUNT(*) as total FROM tickets", [], (e9, totalRow) => {
                    if (e9) return res.status(500).send("Erro ao carregar dados.");
                    res.render("admin-relatorios", {
                      statusData,
                      priorityData,
                      topWeekday,
                      weekdayData,
                      monthlyData,
                      avgTime: avgTime ? avgTime.media_horas : null,
                      categoriesData,
                      agentsData,
                      totalTickets: totalRow ? totalRow.total : 0,
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});

// Minha conta - visualizar dados
app.get("/account", ensureAuthenticated, (req, res) => {
  const userId = req.session.user.id;
  db.get("SELECT id, name, email, role FROM users WHERE id = ?", [userId], (err, user) => {
    if (err || !user) {
      console.error(err);
      return res.status(500).send("Erro ao carregar dados do usuário.");
    }
    res.render("account", { user, error: null, success: null });
  });
});

// Minha conta - atualizar nome, e-mail e senha
app.post("/account", ensureAuthenticated, (req, res) => {
  const userId = req.session.user.id;
  const { name, email, current_password, new_password, confirm_password } = req.body;

  db.get("SELECT * FROM users WHERE id = ?", [userId], (err, user) => {
    if (err || !user) {
      console.error(err);
      return res.status(500).send("Erro ao carregar dados do usuário.");
    }

    let error = null;
    let success = null;

    if (!name || !email) {
      error = "Nome e e-mail são obrigatórios.";
      return res.render("account", { user, error, success });
    }

    const wantsPasswordChange = new_password || confirm_password || current_password;

    if (wantsPasswordChange) {
      if (!current_password || !new_password || !confirm_password) {
        error = "Para alterar a senha, preencha todos os campos de senha.";
        return res.render("account", { user, error, success });
      }

      if (!bcrypt.compareSync(current_password, user.password_hash)) {
        error = "Senha atual incorreta.";
        return res.render("account", { user, error, success });
      }

      if (new_password !== confirm_password) {
        error = "A nova senha e a confirmação não conferem.";
        return res.render("account", { user, error, success });
      }
    }

    const updateUser = (passwordHash = null) => {
      const sql =
        passwordHash !== null
          ? "UPDATE users SET name = ?, email = ?, password_hash = ? WHERE id = ?"
          : "UPDATE users SET name = ?, email = ? WHERE id = ?";

      const params =
        passwordHash !== null ? [name, email, passwordHash, userId] : [name, email, userId];

      db.run(sql, params, function (updateErr) {
        if (updateErr) {
          if (updateErr.code === "SQLITE_CONSTRAINT") {
            error = "Já existe um usuário com esse e-mail.";
          } else {
            console.error(updateErr);
            error = "Erro ao atualizar dados.";
          }
          return res.render("account", { user, error, success });
        }

        // atualizar sessão
        req.session.user.name = name;
        req.session.user.email = email;

        success = "Dados atualizados com sucesso.";
        const updatedUser = { ...user, name, email };
        return res.render("account", { user: updatedUser, error, success });
      });
    };

    if (wantsPasswordChange) {
      const passwordHash = bcrypt.hashSync(new_password, 10);
      updateUser(passwordHash);
    } else {
      updateUser();
    }
  });
});

app.use((err, req, res, next) => {
  if (err && err.code === "EBADCSRFTOKEN") {
    return res.status(403).send("Token CSRF inválido ou expirado. Recarregue a página e tente novamente.");
  }
  return next(err);
});

app.listen(PORT, () => {
  console.log(`Help Desk rodando em http://localhost:${PORT}`);
});

